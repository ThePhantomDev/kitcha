import { Link } from 'react-router-dom';
import { useState } from 'react';
import Sidebar from './Sidebar';

const Navbar = ({ isAuthenticated, logout }) => {
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  return (
    <>
      <nav className="navbar">
        <div className="navbar-container">
          <div className="navbar-start">
            <button className="menu-toggle" onClick={toggleSidebar} aria-label="Toggle Sidebar">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <line x1="3" y1="12" x2="21" y2="12"></line>
                <line x1="3" y1="6" x2="21" y2="6"></line>
                <line x1="3" y1="18" x2="21" y2="18"></line>
              </svg>
            </button>
            <Link to="/" className="navbar-logo">
              Students App
            </Link>
          </div>
          <ul className="nav-menu">
            <li className="nav-item">
              <Link to="/" className="nav-links">
                Home
              </Link>
            </li>
          {isAuthenticated ? (
            <>
              <li className="nav-item">
                <Link to="/home" className="nav-links">
                  Dashboard
                </Link>
              </li>
              <li className="nav-item">
                <button onClick={logout} className="nav-links btn">
                  Logout
                </button>
              </li>
            </>
          ) : (
            <>
              <li className="nav-item">
                <Link to="/login" className="nav-links">
                  Login
                </Link>
              </li>
              <li className="nav-item">
                <Link to="/register" className="nav-links">
                  Register
                </Link>
              </li>
            </>
          )}
        </ul>
      </div>    </nav>
      <Sidebar isOpen={sidebarOpen} toggle={toggleSidebar} isAuthenticated={isAuthenticated} logout={logout} />
    </>
  );
};

export default Navbar;
