// Simple Selenium tests for authentication
import { Builder, By, Key, until } from 'selenium-webdriver';
import chrome from 'selenium-webdriver/chrome.js';

// Test configuration
const BASE_URL = 'http://localhost:5173';
const API_URL = 'http://localhost:5000';

// List of valid test users with valid credentials
const VALID_USERS = [
  { email: 'test1@example.com', password: 'Valid123!' },
  { email: 'test2@example.com', password: 'SecurePwd1#' },
  { email: 'john.doe@company.com', password: 'J0hnD0e@2023' },
  { email: 'mary.smith@email.org', password: 'M@ryPass123' },
  { email: 'developer@tech.io', password: 'C0d3r$ecure!' }
];

// List of invalid emails for testing
const INVALID_EMAILS = [
  'invalid-email',
  'missing@domain',
  '@nodomain.com',
  'spaces in@email.com',
  'missing.dot@com'
];

// List of invalid passwords for testing
const INVALID_PASSWORDS = [
  'short1!',           // Too short
  'NOLOWERCASE123!',   // No lowercase
  'nouppercase123!',   // No uppercase
  'NoNumbers!',        // No numbers
  'NoSymbols123'       // No symbols
];

// Current test user - we'll use the first valid user by default
const CURRENT_USER = VALID_USERS[0];

// Clean up database before testing
async function cleanupDatabase() {
  console.log('Cleaning up database before tests...');
  try {
    // Delete all users from the database
    const response = await fetch(`${API_URL}/api/cleanup-tests`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ secretKey: 'test-cleanup-key' })
    });

    const data = await response.json();
    
    if (response.ok) {
      console.log('Database cleaned successfully:', data.message);
      return true;
    } else {
      console.error('Database cleanup failed:', data.message);
      return false;
    }
  } catch (error) {
    console.error('Database cleanup failed:', error.message);
    return false;
  }
}

// Start the browser
async function startBrowser() {
  // Simple Chrome setup without extra options
  const options = new chrome.Options().addArguments('--headless');
  return await new Builder()
    .forBrowser('chrome')
    // .setChromeOptions(options)
    .build();
}

// Test registration
async function testRegistration(driver) {
  console.log('Testing registration...');
  
  // Choose a random valid user from our list
  const user = VALID_USERS[Math.floor(Math.random() * VALID_USERS.length)];
  console.log(`Attempting to register with email: ${user.email}`);
  
  try {
    // Navigate to register page
    await driver.get(`${BASE_URL}/register`);
    
    // Fill out the form
    await driver.findElement(By.id('email')).sendKeys(user.email);
    await driver.findElement(By.id('password')).sendKeys(user.password);
    await driver.findElement(By.id('confirm-password')).sendKeys(user.password);
    
    // Submit the form
    await driver.findElement(By.className('submit-btn')).click();
    
    // Wait for redirect to login page
    await driver.wait(until.urlIs(`${BASE_URL}/login`), 5000);
    
    console.log('Registration test passed');
    return user; // Return the user that was successfully registered
  } catch (error) {
    console.error('Registration test failed:', error.message);
    return CURRENT_USER; // Return the default user for login tests
  }
}

// Test login
async function testLogin(driver, user) {
  console.log(`Testing login with ${user.email}...`);
  
  try {
    // Navigate to login page
    await driver.get(`${BASE_URL}/login`);
    
    // Fill out the form
    await driver.findElement(By.id('email')).sendKeys(user.email);
    await driver.findElement(By.id('password')).sendKeys(user.password);
    
    // Submit the form
    await driver.findElement(By.className('submit-btn')).click();
    
    // Wait for redirect to home page
    await driver.wait(until.urlIs(`${BASE_URL}/home`), 5000);
    
    // Check that we're logged in
    const welcomeText = await driver.findElement(By.css('.home-container h2')).getText();
    if (!welcomeText.includes(user.email)) {
      throw new Error(`Welcome message doesn't contain user email: ${welcomeText}`);
    }
    
    console.log('Login test passed');
    return true;
  } catch (error) {
    console.error('Login test failed:', error.message);
    return false;
  }
}

// Test invalid login
async function testInvalidLogin(driver, user) {
  console.log('Testing invalid login...');
  
  // Choose a random invalid password from our list
  const invalidPassword = INVALID_PASSWORDS[Math.floor(Math.random() * INVALID_PASSWORDS.length)];
  
  try {
    // Navigate to login page
    await driver.get(`${BASE_URL}/login`);
    
    // Fill out the form with wrong password
    await driver.findElement(By.id('email')).sendKeys(user.email);
    await driver.findElement(By.id('password')).sendKeys(invalidPassword);
    
    // Submit the form
    await driver.findElement(By.className('submit-btn')).click();
    
    // Wait for a moment to see if we're redirected
    await driver.sleep(1000);
    
    // Check if we're still on the login page (form validation prevented submission)
    // or if we get a server-side error
    const currentUrl = await driver.getCurrentUrl();
    if (currentUrl.includes('/login')) {
      console.log('Invalid login test passed - login was rejected');
      return true;
    } else {
      console.error('Invalid login test failed - unexpected navigation occurred');
      return false;
    }
  } catch (error) {
    console.error('Invalid login test failed:', error.message);
    return false;
  }
}

// Test invalid email format
async function testInvalidEmail(driver) {
  console.log('Testing invalid email format...');
  
  // Choose a random invalid email from our list
  const invalidEmail = INVALID_EMAILS[Math.floor(Math.random() * INVALID_EMAILS.length)];
  const password = VALID_USERS[0].password;
  
  try {
    // Navigate to register page
    await driver.get(`${BASE_URL}/register`);
    
    // Fill out the form with invalid email
    await driver.findElement(By.id('email')).sendKeys(invalidEmail);
    // Trigger validation by focusing and then blurring the email field
    await driver.findElement(By.id('email')).sendKeys(Key.TAB);
    
    // Wait briefly to allow validation to occur
    await driver.sleep(500);
    
    // Check if email validation error message appears
    let hasError = false;
    
    try {
      // Try to find the main error message
      hasError = await driver.findElement(By.className('error-message')).isDisplayed();
    } catch (err) {
      // If not found, try the input-specific error message
      try {
        hasError = await driver.findElement(By.className('input-error-message')).isDisplayed();
      } catch (err2) {
        // As a last resort, check if the input has the error class
        try {
          hasError = await driver.findElement(By.css('.input-error')).isDisplayed();
        } catch (err3) {
          throw new Error('No validation error indicators found');
        }
      }
    }
    
    if (hasError) {
      console.log('Invalid email test passed - detected error message/state');
      return true;
    } else {
      throw new Error('Email validation error not displayed');
    }
  } catch (error) {
    console.error('Invalid email test failed:', error.message);
    return false;
  }
}

// Run all tests
async function runTests() {
  let driver;
  
  try {
    // First clean up the database
    await cleanupDatabase();
    
    // Then start the browser and run tests
    driver = await startBrowser();
    
    // Run tests in sequence
    const registeredUser = await testRegistration(driver);
    await testLogin(driver, registeredUser);
    await testInvalidLogin(driver, registeredUser);
    await testInvalidEmail(driver);
    
    console.log('All tests completed!');
  } catch (error) {
    console.error('Test execution failed:', error);
  } finally {
    // Always close the browser
    if (driver) {
      await driver.quit();
    }
  }
}

// Run the tests
runTests();
