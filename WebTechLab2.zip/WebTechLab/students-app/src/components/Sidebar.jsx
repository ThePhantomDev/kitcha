import { Link } from 'react-router-dom';
import './Sidebar.css';
import Overlay from './Overlay';

const Sidebar = ({ isOpen, toggle, isAuthenticated, logout }) => {
  return (
    <>
      <div className={`sidebar ${isOpen ? 'open' : ''}`}>
      <div className="sidebar-header">
        <h3>Students App</h3>
        <button className="close-button" onClick={toggle}>
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <line x1="18" y1="6" x2="6" y2="18"></line>
            <line x1="6" y1="6" x2="18" y2="18"></line>
          </svg>
        </button>
      </div>
      <div className="sidebar-content">
        <ul className="sidebar-menu">
          <li className="sidebar-item">
            <Link to="/" className="sidebar-link" onClick={toggle}>
              Home
            </Link>
          </li>
          
          {isAuthenticated ? (
            <>
              <li className="sidebar-item">
                <Link to="/home" className="sidebar-link" onClick={toggle}>
                  Dashboard
                </Link>
              </li>
              <li className="sidebar-divider"></li>
              <li className="sidebar-item">
                <button 
                  onClick={() => {
                    logout();
                    toggle();
                  }} 
                  className="sidebar-button"
                >
                  Logout
                </button>
              </li>
            </>
          ) : (
            <>
              <li className="sidebar-item">
                <Link to="/login" className="sidebar-link" onClick={toggle}>
                  Login
                </Link>
              </li>
              <li className="sidebar-item">
                <Link to="/register" className="sidebar-link" onClick={toggle}>
                  Register
                </Link>
              </li>
            </>
          )}
        </ul>
      </div>      <div className="sidebar-footer">
        <p>© {new Date().getFullYear()} Students App</p>
      </div>
    </div>
    <Overlay isOpen={isOpen} toggle={toggle} />
    </>
  );
};

export default Sidebar;
