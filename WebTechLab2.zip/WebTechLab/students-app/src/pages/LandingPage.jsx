import { Link } from 'react-router-dom';
import './LandingPage.css';

const LandingPage = () => {
  return (
    <div className="landing-container">
      <div className="landing-content">
        <h1>Welcome to Students App</h1>
        <p>
          A simple application for educational purposes to manage student information.
          Built with React, MongoDB, and PostgreSQL.
        </p>
        <div className="landing-buttons">
          <Link to="/register" className="landing-button register">
            Get Started
          </Link>
          <Link to="/login" className="landing-button login">
            Login
          </Link>
        </div>
        <div className="features">
          <div className="feature-card">
            <h3>User Authentication</h3>
            <p>Secure login and registration system</p>
          </div>
          <div className="feature-card">
            <h3>Student Management</h3>
            <p>Add and view student information</p>
          </div>
          <div className="feature-card">
            <h3>Dual Database Support</h3>
            <p>Built with both MongoDB and PostgreSQL</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LandingPage;
