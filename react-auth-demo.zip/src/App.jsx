import { useState } from 'react'
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom'
import './App.css'
import Login from './Login'
import Register from './Register'
import Home from './Home'

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [userEmail, setUserEmail] = useState('')

  const handleLogin = (email) => {
    setIsLoggedIn(true)
    setUserEmail(email)
  }

  const handleLogout = () => {
    setIsLoggedIn(false)
    setUserEmail('')
  }

  return (
    <Router>
      <div className="app-container">
        <h1>React Auth Demo</h1>
        <Routes>
          <Route path="/login" element={
            isLoggedIn ? 
              <Navigate to="/home" /> : 
              <Login onLogin={handleLogin} />
          } />
          <Route path="/register" element={
            isLoggedIn ? 
              <Navigate to="/home" /> : 
              <Register />
          } />
          <Route path="/home" element={
            isLoggedIn ? 
              <Home userEmail={userEmail} onLogout={handleLogout} /> : 
              <Navigate to="/login" />
          } />
          <Route path="*" element={<Navigate to="/login" />} />
        </Routes>
      </div>
    </Router>
  )
}

export default App
