import { useState, useEffect } from 'react';
import axios from 'axios';
import './Home.css';

const Home = () => {
  const [students, setStudents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    course: '',
    grade: '',
  });
  const [showForm, setShowForm] = useState(false);
  
  const username = localStorage.getItem('username');
  const dbType = localStorage.getItem('dbType') || 'mongodb';
  const baseUrl = dbType === 'mongodb' ? 'http://localhost:5000' : 'http://localhost:5001';

  useEffect(() => {
    fetchStudents();
  }, []);

  const fetchStudents = async () => {
    try {
      setLoading(true);
      const token = localStorage.getItem('token');
      
      const res = await axios.get(`${baseUrl}/api/students`, {
        headers: {
          'x-auth-token': token
        }
      });
      
      setStudents(res.data);
    } catch (err) {
      setError('Error fetching students');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    try {
      const token = localStorage.getItem('token');
      
      await axios.post(`${baseUrl}/api/students`, formData, {
        headers: {
          'x-auth-token': token
        }
      });
      
      // Clear form data and hide form
      setFormData({ name: '', email: '', course: '', grade: '' });
      setShowForm(false);
      
      // Refresh student list
      fetchStudents();
    } catch (err) {
      setError('Error adding student');
      console.error(err);
    }
  };

  return (
    <div className="home-container">
      <div className="home-header">
        <h1>Welcome, {username}!</h1>
        <p>You are currently using the {dbType === 'mongodb' ? 'MongoDB' : 'PostgreSQL'} database.</p>
      </div>

      <div className="student-management">
        <div className="student-header">
          <h2>Students List</h2>
          <button onClick={() => setShowForm(!showForm)} className="add-button">
            {showForm ? 'Cancel' : 'Add Student'}
          </button>
        </div>

        {error && <div className="error-message">{error}</div>}

        {showForm && (
          <div className="student-form-container">
            <h3>Add New Student</h3>
            <form onSubmit={handleSubmit} className="student-form">
              <div className="form-group">
                <label htmlFor="name">Name</label>
                <input
                  type="text"
                  name="name"
                  id="name"
                  value={formData.name}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="form-group">
                <label htmlFor="email">Email</label>
                <input
                  type="email"
                  name="email"
                  id="email"
                  value={formData.email}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="form-group">
                <label htmlFor="course">Course</label>
                <input
                  type="text"
                  name="course"
                  id="course"
                  value={formData.course}
                  onChange={handleChange}
                  required
                />
              </div>
              <div className="form-group">
                <label htmlFor="grade">Grade</label>
                <input
                  type="text"
                  name="grade"
                  id="grade"
                  value={formData.grade}
                  onChange={handleChange}
                />
              </div>
              <button type="submit" className="submit-button">Add Student</button>
            </form>
          </div>
        )}

        {loading ? (
          <div className="loading">Loading students...</div>
        ) : students.length > 0 ? (
          <div className="student-list">
            <table>
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Course</th>
                  <th>Grade</th>
                </tr>
              </thead>
              <tbody>
                {students.map((student) => (
                  <tr key={student.id || student._id}>
                    <td>{student.name}</td>
                    <td>{student.email}</td>
                    <td>{student.course}</td>
                    <td>{student.grade || 'N/A'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="empty-message">
            No students found. Add a student to get started!
          </div>
        )}
      </div>
    </div>
  );
};

export default Home;
