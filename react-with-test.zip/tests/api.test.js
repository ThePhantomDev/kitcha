import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import express from 'express';
import cors from 'cors';
import Database from 'better-sqlite3';

const app = express();
app.use(cors());
app.use(express.json());

const db = new Database(':memory:'); // Use in-memory SQLite for testing

// Create users table
beforeAll(() => {
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      email TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL
    )
  `);

  // Add route handlers
  const findUser = db.prepare('SELECT * FROM users WHERE email = ?');
  const createUser = db.prepare('INSERT INTO users (email, password) VALUES (?, ?)');

  app.post('/api/register', (req, res) => {
    try {
      const { email, password } = req.body;
      const existingUser = findUser.get(email);
      if (existingUser) {
        return res.status(400).json({ message: 'Email already registered' });
      }
      createUser.run(email, password);
      res.status(201).json({ message: 'User registered successfully' });
    } catch (error) {
      res.status(500).json({ message: 'Server error' });
    }
  });

  app.post('/api/login', (req, res) => {
    try {
      const { email, password } = req.body;
      const user = findUser.get(email);
      if (!user || user.password !== password) {
        return res.status(401).json({ message: 'Invalid credentials' });
      }
      res.json({ message: 'Login successful' });
    } catch (error) {
      res.status(500).json({ message: 'Server error' });
    }
  });
});

afterAll(() => {
  db.close();
});

describe('Auth API', () => {
  const testUser = {
    email: 'test@example.com',
    password: 'Test123!'
  };

  describe('POST /api/register', () => {
    it('should register a new user successfully', async () => {
      const response = await request(app)
        .post('/api/register')
        .send(testUser);
      
      expect(response.status).toBe(201);
      expect(response.body.message).toBe('User registered successfully');
    });

    it('should not allow duplicate email registration', async () => {
      const response = await request(app)
        .post('/api/register')
        .send(testUser);
      
      expect(response.status).toBe(400);
      expect(response.body.message).toBe('Email already registered');
    });
  });

  describe('POST /api/login', () => {
    it('should login successfully with correct credentials', async () => {
      const response = await request(app)
        .post('/api/login')
        .send(testUser);
      
      expect(response.status).toBe(200);
      expect(response.body.message).toBe('Login successful');
    });

    it('should fail with incorrect password', async () => {
      const response = await request(app)
        .post('/api/login')
        .send({
          email: testUser.email,
          password: 'wrongpassword'
        });
      
      expect(response.status).toBe(401);
      expect(response.body.message).toBe('Invalid credentials');
    });

    it('should fail with non-existent email', async () => {
      const response = await request(app)
        .post('/api/login')
        .send({
          email: 'nonexistent@example.com',
          password: 'Test123!'
        });
      
      expect(response.status).toBe(401);
      expect(response.body.message).toBe('Invalid credentials');
    });
  });
});
