import React from 'react';
import './App.css';

function Home({ userEmail, onLogout }) {
  return (
    <div className="home-container">
      <h2>Welcome, {userEmail}!</h2>
      <p>You have successfully logged in to the application.</p>
      <p>This is a simple authentication demo with React, showing how to implement:</p>
      <ul>
        <li>User registration</li>
        <li>User login</li>
        <li>Protected routes</li>
      </ul>
      <p>The backend is available in two versions:</p>
      <ul>
        <li>MongoDB version (server-mongodb.js)</li>
        <li>SQLite version (server-sqlite.js)</li>
      </ul>
      <p>Both servers provide the same functionality, making this a good example for testing different database implementations.</p>
      
      <button onClick={onLogout} className="logout-btn">
        Logout
      </button>
    </div>
  );
}

export default Home;
