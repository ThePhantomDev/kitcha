import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import './App.css';

function Register() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');
  const [emailError, setEmailError] = useState('');
  const [loading, setLoading] = useState(false);
  const [passwordStrength, setPasswordStrength] = useState('');
  const navigate = useNavigate();
  
  const validateEmail = (email) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      setEmailError('Invalid email format. Please use a valid email address.');
      return false;
    }
    setEmailError('');
    return true;
  };
  
  const handleEmailChange = (e) => {
    setEmail(e.target.value);
    if (e.target.value) validateEmail(e.target.value);
    else setEmailError('');
  };
  
  const checkPasswordStrength = (pass) => {
    // Has at least 6 characters
    const hasMinLength = pass.length >= 6;
    
    // Has letters
    const hasLetters = /[A-Za-z]/.test(pass);
    
    // Has numbers
    const hasNumbers = /\d/.test(pass);
    
    // Has special characters
    const hasSpecialChars = /[@$!%*#?&]/.test(pass);
    
    if (hasMinLength && hasLetters && hasNumbers && hasSpecialChars) {
      return 'strong';
    } else if (hasMinLength && (hasLetters && hasNumbers || hasLetters && hasSpecialChars || hasNumbers && hasSpecialChars)) {
      return 'medium';
    } else if (pass.length > 0) {
      return 'weak';
    } else {
      return '';
    }
  };
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setEmailError('');

    // Email validation
    if (!validateEmail(email)) {
      return;
    }
      
    // Password validation
    const passwordRegex = /^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!%*#?&]{6,}$/;
    if (!passwordRegex.test(password)) {
      setError('Password must be at least 6 characters long and include at least one letter, one number, and one special character');
      return;
    }
    
    // Confirm password validation
    if (password !== confirmPassword) {
      setError('Passwords do not match');
      return;
    }

    setLoading(true);

    try {
      const response = await fetch('http://localhost:5000/api/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, password }),
      });

      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.message || 'Registration failed');
      }
      
      // Redirect to login page on success
      navigate('/login');
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-container">
      <h2>Register</h2>
      
      {error && <div className="error-message">{error}</div>}
      
      <form onSubmit={handleSubmit} className="auth-form">
        <div className="form-group">
          <label htmlFor="email">Email</label>
          <input
            id="email"
            type="email"
            value={email}
            onChange={handleEmailChange}
            onBlur={() => validateEmail(email)}
            placeholder="example@email.com"
            className={emailError ? 'input-error' : ''}
            required
          />
          {emailError && <div className="input-error-message">{emailError}</div>}
          <p className="validation-hint">Please enter a valid email address (e.g., example@email.com)</p>
        </div>
        
        <div className="form-group">
          <label htmlFor="password">Password</label>
          <input
            id="password"
            type="password"
            value={password}
            onChange={(e) => {
              setPassword(e.target.value);
              setPasswordStrength(checkPasswordStrength(e.target.value));
            }}
            placeholder="Min. 6 chars with letter, number, symbol"
            pattern="^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!%*#?&]{6,}$"
            title="Password must be at least 6 characters with letters, numbers, and special characters"
            required
          />
          <div className="password-strength">
            {passwordStrength && (
              <div className={`password-strength-meter strength-${passwordStrength}`}></div>
            )}
          </div>
          <p className="validation-hint">
            {passwordStrength === 'strong' ? 'Strong password!' : 
             passwordStrength === 'medium' ? 'Medium strength - add more variety' :
             passwordStrength === 'weak' ? 'Weak password - add letters, numbers, and special characters' :
             'Password must include letters, numbers, and special characters (@$!%*#?&)'}
          </p>
        </div>
        
        <div className="form-group">
          <label htmlFor="confirm-password">Confirm Password</label>
          <input
            id="confirm-password"
            type="password"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            required
          />
        </div>
        
        <button type="submit" disabled={loading || emailError} className="submit-btn">
          {loading ? 'Registering...' : 'Register'}
        </button>
      </form>
      
      <p className="auth-redirect">
        Already have an account? <Link to="/login">Login</Link>
      </p>
    </div>
  );
}

export default Register;
